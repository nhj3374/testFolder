package kr.co.agmo.mvc.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.co.agmo.mvc.dao.AgmoDaoInter;
import kr.co.agmo.mvc.dto.MemberVO;


@Controller
public class AgmoUserController {

	@Autowired
	private AgmoDaoInter agmoDaoInter;

	@RequestMapping(value = "/MemberList")
	public String updemoList(Model m) {
		List<MemberVO> list = agmoDaoInter.getList();
		m.addAttribute("list", list);
		return "user/MemberList";
	}
}
