package kr.co.agmo.mvc.dto;

import java.sql.Date;

public class MemberVO {
   
   private long member_idx;
   private String member_name;
   private String id;
   private String pwd;
   private String email;
   private Date birthdate;
   private String gender;
   private int grade_idx;
   private int pref_A_idx;
   private int pref_B_idx;
   private int pref_C_idx;
   public long getMember_idx() {
      return member_idx;
   }
   public void setMember_idx(long member_idx) {
      this.member_idx = member_idx;
   }
   public String getMember_name() {
      return member_name;
   }
   public void setMember_name(String member_name) {
      this.member_name = member_name;
   }
   public String getId() {
      return id;
   }
   public void setId(String id) {
      this.id = id;
   }
   public String getPwd() {
      return pwd;
   }
   public void setPwd(String pwd) {
      this.pwd = pwd;
   }
   public String getEmail() {
      return email;
   }
   public void setEmail(String email) {
      this.email = email;
   }
   public Date getBirthdate() {
      return birthdate;
   }
   public void setBirthdate(Date birthdate) {
      this.birthdate = birthdate;
   }
   public String getGender() {
      return gender;
   }
   public void setGender(String gender) {
      this.gender = gender;
   }
   public int getGrade_idx() {
      return grade_idx;
   }
   public void setGrade_idx(int grade_idx) {
      this.grade_idx = grade_idx;
   }
   public int getPref_A_idx() {
      return pref_A_idx;
   }
   public void setPref_A_idx(int pref_A_idx) {
      this.pref_A_idx = pref_A_idx;
   }
   public int getPref_B_idx() {
      return pref_B_idx;
   }
   public void setPref_B_idx(int pref_B_idx) {
      this.pref_B_idx = pref_B_idx;
   }
   public int getPref_C_idx() {
      return pref_C_idx;
   }
   public void setPref_C_idx(int pref_C_idx) {
      this.pref_C_idx = pref_C_idx;
   }

}