package kr.co.agmo.mvc.dao;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.agmo.mvc.dto.MemberVO;

@Repository 
public class AgmoDaoImple implements AgmoDaoInter {
	
	@Autowired
	private SqlSessionTemplate ss;
	
	@Override
	public List<MemberVO> getList() {
		return ss.selectList("agmo.memList");
	}


}
