package kr.co.agmo.mvc.dao;

import java.util.List;

import kr.co.agmo.mvc.dto.MemberVO;


public interface AgmoDaoInter {

	public List<MemberVO> getList();
	
}
